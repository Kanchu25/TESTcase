package com.fujitsu.loginAndRegistration.controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fujitsu.loginAndRegistration.DAO.UserDao;

@WebServlet("/UserController")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		UserDao dao = new UserDao();
		ResultSet rs = dao.userDetails();
		ArrayList userlist = new ArrayList<>();
		try {
			while (rs.next())
			{
				{
					System.out.println("\n");
					 userlist.add( "id :"  +rs.getInt(1)); 
					 userlist.add( "username :" +rs.getString(2)); 
					 userlist.add("password :" +rs.getString(3)); 
					 userlist.add( "Phone:"  +rs.getInt(4));
					 userlist.add("address: " +rs.getString(5));
					 
					 
				}
				
			}
			request.setAttribute("userlist", userlist);
			RequestDispatcher dispatcher = request.getRequestDispatcher("admin.jsp");
            dispatcher.forward(request, response);
            
			for (int i = 0; i < userlist.size(); i++)
				System.out.println(userlist.get(i));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}