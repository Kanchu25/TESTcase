package com.fujitsu.loginAndRegistration.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fujitsu.loginAndRegistration.DAO.LoginDao;

@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
    	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	    System.out.println("start of dopost");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		LoginDao dao= new LoginDao();
		boolean result =dao.verifyUserCredentials(username, password);
		
		if(result)
		{
			System.out.println("Executing if block" + result);
		     
			HttpSession session=request.getSession();
		    session.setAttribute("userName", username);
		    
		    System.out.println("redirected response to welcome page" + result);
		    response.sendRedirect("welcome.jsp");
		    
		    
		}
		else
		{
			response.sendRedirect("Login.jsp");
		}
		System.out.println("end of do post");
	}
}

