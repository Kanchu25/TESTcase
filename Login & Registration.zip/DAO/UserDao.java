package com.fujitsu.loginAndRegistration.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

public class UserDao {
	
	public ResultSet userDetails () {
		
		
		String url="jdbc:mysql://localhost:3306/test";
		String db_username="root";
		String db_password="Myroot@123";
		
		Connection con;
		Statement stmt;
		ResultSet rs=null;
		String sql="select * from user4";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection(url, db_username, db_password);
			stmt=con.createStatement();
			rs=stmt.executeQuery(sql);
            	
          }
		catch(Exception e){
			e.printStackTrace();
		}
		
			return rs;
		}
      

}
