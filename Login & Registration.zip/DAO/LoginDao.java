package com.fujitsu.loginAndRegistration.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginDao {
	
	public boolean verifyUserCredentials(String userName, String password) {
		
	String url="jdbc:mysql://localhost:3306/test";
	String db_userName="root";
	String db_password="Myroot@123";
	
	String sql="select * from user3 where userName=? and password=?";
	Connection con;
	PreparedStatement pstmt;
	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection(url, db_userName, db_password);
    
		pstmt=con.prepareStatement(sql);
		pstmt.setString(1, userName);
		pstmt.setString(2, password);
		
		ResultSet rs= pstmt.executeQuery();
		
		if(rs.next())
			return true;
		
		
	   } catch (Exception e) {
    	  
      }
	return false;
}
}